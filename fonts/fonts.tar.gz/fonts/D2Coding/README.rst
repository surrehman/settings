D2Coding for Powerline
======================

:Font creator: Naver (company)
:Source: https://github.com/naver/d2codingfont
:Patched by: `Kang Min Yoo <https://github.com/kaniblu>`_

D2Coding is a monospace font developed by a Korean IT Company called Naver. Font 
is good for displaying both Korean characters and latin characters, as sometimes 
these two languages could share some similar strokes.
